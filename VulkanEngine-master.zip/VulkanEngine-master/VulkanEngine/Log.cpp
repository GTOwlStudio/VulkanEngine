#include "Log.h"



CLog::CLog()
{
}


CLog::~CLog()
{
}
