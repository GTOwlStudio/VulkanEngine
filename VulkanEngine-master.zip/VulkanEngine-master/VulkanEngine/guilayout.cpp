#include "guitools.h"
/*
GuiLayout::GuiLayout() {

}

GuiLayout::~GuiLayout() {

}

void GuiLayout::addObject(GuiObject object, GuiObject *parents)
{

}*/
